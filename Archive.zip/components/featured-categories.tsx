"use client"

import { useEffect, useState } from "react"
import Link from "next/link"
import { Card, CardContent } from "@/components/ui/card"
import { ArrowRight, Crown } from 'lucide-react'

interface Product {
  id: string
  name: string
  image_url: string
  featured_collections?: string
}

interface Category {
  id: string
  title: string
  description: string
  color: string
  href: string
  products?: Product[]
}

export function FeaturedCategories() {
  const [products, setProducts] = useState<Product[]>([])
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    fetchProducts()
  }, [])

  const fetchProducts = async () => {
    try {
      const response = await fetch("/api/products")
      if (response.ok) {
        const data = await response.json()
        console.log("[v0] Featured categories fetched products:", data.length, "total")
        setProducts(data)
      }
    } catch (error) {
      console.error("Error fetching products:", error)
    } finally {
      setIsLoading(false)
    }
  }

  const categories: Category[] = [
    {
      id: "womens-hot-pick",
      title: "Women's Hot Pick",
      description: "Timeless elegance crafted with 35+ years of expertise",
      href: "/categories/women?collection=womens-hot-pick",
      color: "from-amber-400 to-yellow-500",
    },
    {
      id: "traditional-ethnic",
      title: "Traditional Ethnic Wear",
      description: "Authentic Indian craftsmanship meets modern comfort",
      href: "/categories/women?collection=traditional-ethnic",
      color: "from-orange-400 to-red-500",
    },
    {
      id: "childrens-premium",
      title: "Children's Premium Line",
      description: "Gentle fabrics and playful designs for little treasures",
      href: "/categories/kids?collection=childrens-premium",
      color: "from-yellow-400 to-orange-500",
    },
    {
      id: "curated-casual",
      title: "Curated Casual Wear",
      description: "Effortless style for everyday elegance",
      href: "/categories/women?collection=curated-casual",
      color: "from-amber-500 to-yellow-600",
    },
  ]

  // Map products to collections
  const categoriesWithProducts = categories.map((category) => ({
    ...category,
    products: products.filter((product) => {
      try {
        const collections = product.featured_collections ? JSON.parse(product.featured_collections) : []
        console.log("[v0] Checking product", product.id, "collections:", collections, "looking for:", category.id)
        return collections.includes(category.id)
      } catch (e) {
        console.error("[v0] Error parsing collections for product", product.id, "raw value:", product.featured_collections, "error:", e)
        return false
      }
    }),
  }))

  return (
    <section className="py-12 sm:py-16 bg-gradient-to-b from-amber-50/50 to-white">
      <div className="container mx-auto px-4">
        <div className="text-center mb-8 sm:mb-12">
          <div className="flex items-center justify-center mb-4">
            <Crown className="h-8 w-8 text-amber-600 mr-3" />
            <h2 className="text-2xl sm:text-3xl md:text-4xl font-bold text-gray-900">Curated Collections</h2>
          </div>
          <p className="text-lg sm:text-xl text-gray-600 max-w-3xl mx-auto">
            Explore our carefully curated collections, each piece selected with the wisdom of three decades in fashion
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6">
          {categoriesWithProducts.map((category) => (
            <Link key={category.id} href={category.href}>
              <Card className="group hover:shadow-2xl transition-all duration-500 transform hover:-translate-y-3 overflow-hidden border border-amber-200 bg-gradient-to-b from-white to-amber-50/30">
                <div className="relative">
                  {/* Display first product image if available, otherwise placeholder */}
                  <img
                    src={category.products?.[0]?.image_url || "/placeholder.svg?height=300&width=400"}
                    alt={category.title}
                    className="w-full h-48 sm:h-56 object-cover group-hover:scale-110 transition-transform duration-500"
                  />
                  <div
                    className={`absolute inset-0 bg-gradient-to-t ${category.color} opacity-20 group-hover:opacity-30 transition-opacity duration-500`}
                  ></div>
                  <div className="absolute top-4 right-4">
                    <Crown className="h-6 w-6 text-white drop-shadow-lg" />
                  </div>
                </div>
                <CardContent className="p-4 sm:p-6">
                  <h3 className="text-lg sm:text-xl font-semibold text-gray-900 mb-3 group-hover:text-amber-600 transition-colors">
                    {category.title}
                  </h3>
                  <p className="text-gray-600 mb-4 text-sm sm:text-base">{category.description}</p>
                  <div className="flex items-center justify-between text-sm">
                    <div className="flex items-center text-amber-600 font-medium group-hover:text-amber-700">
                      <span>Explore Collection</span>
                      <ArrowRight className="h-4 w-4 ml-2 group-hover:translate-x-1 transition-transform" />
                    </div>
                    {category.products && category.products.length > 0 && (
                      <span className="text-gray-500 text-xs bg-amber-50 px-2 py-1 rounded">
                        {category.products.length} items
                      </span>
                    )}
                  </div>
                </CardContent>
              </Card>
            </Link>
          ))}
        </div>
      </div>
    </section>
  )
}
