import { initializeApp, getApps, cert } from "firebase-admin/app"
import { getAuth } from "firebase-admin/auth"
import { getStorage } from "firebase-admin/storage"
import { FIREBASE_ADMIN_CONFIG } from "./env"

// Initialize Firebase Admin SDK
const firebaseAdminApp =
  getApps().find((app) => app.name === "admin") ||
  initializeApp(
    {
      credential: cert({
        projectId: FIREBASE_ADMIN_CONFIG.projectId,
        clientEmail: FIREBASE_ADMIN_CONFIG.clientEmail,
        privateKey: FIREBASE_ADMIN_CONFIG.privateKey,
      }),
      storageBucket: `${FIREBASE_ADMIN_CONFIG.projectId}.appspot.com`,
    },
    "admin",
  )

export const adminAuth = getAuth(firebaseAdminApp)
export const adminStorage = getStorage(firebaseAdminApp)

export default firebaseAdminApp
