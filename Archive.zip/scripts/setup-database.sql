-- Create products table
CREATE TABLE IF NOT EXISTS products (
  id SERIAL PRIMARY KEY,
  name VARCHAR(255) NOT NULL,
  description TEXT NOT NULL,
  price DECIMAL(10,2) NOT NULL,
  original_price DECIMAL(10,2) NOT NULL,
  category VARCHAR(50) NOT NULL,
  stock INTEGER NOT NULL DEFAULT 0,
  image_url TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create orders table
CREATE TABLE IF NOT EXISTS orders (
  id SERIAL PRIMARY KEY,
  user_email VARCHAR(255) NOT NULL,
  total_amount DECIMAL(10,2) NOT NULL,
  status VARCHAR(50) DEFAULT 'pending',
  shipping_address TEXT NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create order_items table
CREATE TABLE IF NOT EXISTS order_items (
  id SERIAL PRIMARY KEY,
  order_id INTEGER REFERENCES orders(id),
  product_id INTEGER REFERENCES products(id),
  quantity INTEGER NOT NULL,
  price DECIMAL(10,2) NOT NULL
);

-- Insert sample products
INSERT INTO products (name, description, price, original_price, category, stock, image_url) VALUES
('Elegant Silk Saree', 'Beautiful handwoven silk saree with traditional patterns', 8999, 12999, 'women', 15, '/placeholder.svg?height=400&width=300&text=Silk+Saree'),
('Designer Kurti Set', 'Premium cotton kurti with matching dupatta', 2499, 3499, 'women', 25, '/placeholder.svg?height=400&width=300&text=Kurti+Set'),
('Kids Party Dress', 'Adorable party dress for special occasions', 1899, 2499, 'kids', 20, '/placeholder.svg?height=400&width=300&text=Kids+Dress'),
('Traditional Lehenga', 'Stunning lehenga for weddings and festivals', 15999, 19999, 'women', 8, '/placeholder.svg?height=400&width=300&text=Lehenga'),
('Kids Ethnic Wear', 'Comfortable ethnic wear for kids', 1299, 1699, 'kids', 30, '/placeholder.svg?height=400&width=300&text=Kids+Ethnic'),
('Cotton Salwar Suit', 'Comfortable cotton salwar suit for daily wear', 1999, 2799, 'women', 18, '/placeholder.svg?height=400&width=300&text=Salwar+Suit');
