"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { useAuth } from "@/hooks/use-firebase-auth"
import { useToast } from "@/hooks/use-toast"
import {
  Package,
  Search,
  Calendar,
  User,
  MapPin,
  DollarSign,
  Truck,
  CheckCircle,
  Clock,
  AlertCircle,
  Loader2,
  Eye,
  Edit,
} from "lucide-react"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

interface OrderItem {
  id: string
  name: string
  price: number
  quantity: number
  image: string
}

interface Order {
  id: string
  orderNumber: string
  customerEmail: string
  customerName: string
  date: string
  status: "pending" | "processing" | "shipped" | "delivered" | "cancelled"
  items: OrderItem[]
  totalAmount: number
  shippingAddress: {
    name: string
    street: string
    city: string
    state: string
    pincode: string
    phone: string
  }
  paymentMethod: string
  trackingNumber?: string
}

export default function AdminOrdersPage() {
  const { user, isAdmin, loading } = useAuth()
  const { toast } = useToast()
  const [orders, setOrders] = useState<Order[]>([])
  const [filteredOrders, setFilteredOrders] = useState<Order[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [searchTerm, setSearchTerm] = useState("")
  const [statusFilter, setStatusFilter] = useState<string>("all")
  const [timeFilter, setTimeFilter] = useState<string>("all")

  useEffect(() => {
    if (!loading && user && isAdmin) {
      loadOrders()
    } else if (!loading) {
      setIsLoading(false)
    }
  }, [loading, user, isAdmin])

  useEffect(() => {
    filterOrders()
  }, [orders, searchTerm, statusFilter, timeFilter])

  const loadOrders = async () => {
    try {
      // Mock orders data - in real app, fetch from API
      const mockOrders: Order[] = [
        {
          id: "1",
          orderNumber: "GT-2024-001",
          customerEmail: "john@example.com",
          customerName: "John Doe",
          date: "2024-01-15T10:30:00Z",
          status: "delivered",
          items: [
            {
              id: "1",
              name: "Elegant Silk Dress",
              price: 2999,
              quantity: 1,
              image: "/placeholder.svg?height=60&width=60",
            },
            {
              id: "2",
              name: "Cotton Kids T-Shirt",
              price: 599,
              quantity: 2,
              image: "/placeholder.svg?height=60&width=60",
            },
          ],
          totalAmount: 4197,
          shippingAddress: {
            name: "John Doe",
            street: "123 Main Street, Apartment 4B",
            city: "Mumbai",
            state: "Maharashtra",
            pincode: "400001",
            phone: "+91 9876543210",
          },
          paymentMethod: "Credit Card",
          trackingNumber: "GT123456789",
        },
        {
          id: "2",
          orderNumber: "GT-2024-002",
          customerEmail: "jane@example.com",
          customerName: "Jane Smith",
          date: "2024-01-20T14:15:00Z",
          status: "shipped",
          items: [
            {
              id: "3",
              name: "Designer Handbag",
              price: 1999,
              quantity: 1,
              image: "/placeholder.svg?height=60&width=60",
            },
          ],
          totalAmount: 2199,
          shippingAddress: {
            name: "Jane Smith",
            street: "456 Oak Avenue",
            city: "Delhi",
            state: "Delhi",
            pincode: "110001",
            phone: "+91 9876543211",
          },
          paymentMethod: "UPI",
          trackingNumber: "GT987654321",
        },
        {
          id: "3",
          orderNumber: "GT-2024-003",
          customerEmail: "bob@example.com",
          customerName: "Bob Johnson",
          date: "2024-01-22T09:45:00Z",
          status: "processing",
          items: [
            {
              id: "4",
              name: "Kids Summer Dress",
              price: 899,
              quantity: 1,
              image: "/placeholder.svg?height=60&width=60",
            },
            {
              id: "5",
              name: "Women's Casual Top",
              price: 799,
              quantity: 1,
              image: "/placeholder.svg?height=60&width=60",
            },
          ],
          totalAmount: 1898,
          shippingAddress: {
            name: "Bob Johnson",
            street: "789 Pine Street",
            city: "Bangalore",
            state: "Karnataka",
            pincode: "560001",
            phone: "+91 9876543212",
          },
          paymentMethod: "Cash on Delivery",
        },
        {
          id: "4",
          orderNumber: "GT-2024-004",
          customerEmail: "alice@example.com",
          customerName: "Alice Brown",
          date: "2024-01-23T16:20:00Z",
          status: "pending",
          items: [
            {
              id: "6",
              name: "Formal Blazer",
              price: 3499,
              quantity: 1,
              image: "/placeholder.svg?height=60&width=60",
            },
          ],
          totalAmount: 3699,
          shippingAddress: {
            name: "Alice Brown",
            street: "321 Elm Street",
            city: "Chennai",
            state: "Tamil Nadu",
            pincode: "600001",
            phone: "+91 9876543213",
          },
          paymentMethod: "Net Banking",
        },
        {
          id: "5",
          orderNumber: "GT-2024-005",
          customerEmail: "charlie@example.com",
          customerName: "Charlie Wilson",
          date: "2024-01-18T11:30:00Z",
          status: "cancelled",
          items: [
            {
              id: "7",
              name: "Sports Shoes",
              price: 2499,
              quantity: 1,
              image: "/placeholder.svg?height=60&width=60",
            },
          ],
          totalAmount: 2699,
          shippingAddress: {
            name: "Charlie Wilson",
            street: "654 Maple Avenue",
            city: "Pune",
            state: "Maharashtra",
            pincode: "411001",
            phone: "+91 9876543214",
          },
          paymentMethod: "Credit Card",
        },
      ]

      // Simulate API delay
      await new Promise((resolve) => setTimeout(resolve, 1000))
      setOrders(mockOrders)
    } catch (error) {
      console.error("Error loading orders:", error)
      toast({
        title: "Error",
        description: "Failed to load orders",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  const filterOrders = () => {
    let filtered = [...orders]

    // Search filter
    if (searchTerm) {
      filtered = filtered.filter(
        (order) =>
          order.orderNumber.toLowerCase().includes(searchTerm.toLowerCase()) ||
          order.customerName.toLowerCase().includes(searchTerm.toLowerCase()) ||
          order.customerEmail.toLowerCase().includes(searchTerm.toLowerCase()),
      )
    }

    // Status filter
    if (statusFilter !== "all") {
      filtered = filtered.filter((order) => order.status === statusFilter)
    }

    // Time filter
    if (timeFilter !== "all") {
      const now = new Date()
      const filterDate = new Date()

      switch (timeFilter) {
        case "today":
          filterDate.setHours(0, 0, 0, 0)
          break
        case "week":
          filterDate.setDate(now.getDate() - 7)
          break
        case "month":
          filterDate.setMonth(now.getMonth() - 1)
          break
        case "year":
          filterDate.setFullYear(now.getFullYear() - 1)
          break
      }

      filtered = filtered.filter((order) => new Date(order.date) >= filterDate)
    }

    setFilteredOrders(filtered)
  }

  const updateOrderStatus = async (orderId: string, newStatus: Order["status"]) => {
    try {
      // In real app, call API to update order status
      setOrders(orders.map((order) => (order.id === orderId ? { ...order, status: newStatus } : order)))

      toast({
        title: "Success",
        description: "Order status updated successfully",
      })
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to update order status",
        variant: "destructive",
      })
    }
  }

  const getStatusColor = (status: Order["status"]) => {
    switch (status) {
      case "pending":
        return "bg-yellow-100 text-yellow-800"
      case "processing":
        return "bg-blue-100 text-blue-800"
      case "shipped":
        return "bg-purple-100 text-purple-800"
      case "delivered":
        return "bg-green-100 text-green-800"
      case "cancelled":
        return "bg-red-100 text-red-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  const getStatusIcon = (status: Order["status"]) => {
    switch (status) {
      case "pending":
        return <Clock className="h-4 w-4" />
      case "processing":
        return <Package className="h-4 w-4" />
      case "shipped":
        return <Truck className="h-4 w-4" />
      case "delivered":
        return <CheckCircle className="h-4 w-4" />
      case "cancelled":
        return <AlertCircle className="h-4 w-4" />
      default:
        return <Package className="h-4 w-4" />
    }
  }

  const getOrderStats = () => {
    const stats = {
      total: orders.length,
      pending: orders.filter((o) => o.status === "pending").length,
      processing: orders.filter((o) => o.status === "processing").length,
      shipped: orders.filter((o) => o.status === "shipped").length,
      delivered: orders.filter((o) => o.status === "delivered").length,
      cancelled: orders.filter((o) => o.status === "cancelled").length,
      totalRevenue: orders.filter((o) => o.status !== "cancelled").reduce((sum, o) => sum + o.totalAmount, 0),
    }
    return stats
  }

  if (loading || isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin" />
      </div>
    )
  }

  if (!user || !isAdmin) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Card className="w-96">
          <CardContent className="pt-6">
            <div className="text-center">
              <AlertCircle className="h-12 w-12 text-red-500 mx-auto mb-4" />
              <h2 className="text-xl font-semibold mb-2">Access Denied</h2>
              <p className="text-gray-600 mb-4">You need admin privileges to access this page.</p>
              <Button onClick={() => (window.location.href = "/admin")}>Go to Admin</Button>
            </div>
          </CardContent>
        </Card>
      </div>
    )
  }

  const stats = getOrderStats()

  return (
    <div className="min-h-screen bg-gradient-to-br from-amber-50 to-orange-50">
      <div className="container mx-auto px-4 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-amber-800 mb-2">Order Management</h1>
          <p className="text-gray-600">Manage and track all customer orders</p>
        </div>

        {/* Order Statistics */}
        <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-7 gap-4 mb-8">
          <Card>
            <CardContent className="pt-4">
              <div className="text-center">
                <div className="text-2xl font-bold">{stats.total}</div>
                <div className="text-sm text-gray-600">Total Orders</div>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="pt-4">
              <div className="text-center">
                <div className="text-2xl font-bold text-yellow-600">{stats.pending}</div>
                <div className="text-sm text-gray-600">Pending</div>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="pt-4">
              <div className="text-center">
                <div className="text-2xl font-bold text-blue-600">{stats.processing}</div>
                <div className="text-sm text-gray-600">Processing</div>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="pt-4">
              <div className="text-center">
                <div className="text-2xl font-bold text-purple-600">{stats.shipped}</div>
                <div className="text-sm text-gray-600">Shipped</div>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="pt-4">
              <div className="text-center">
                <div className="text-2xl font-bold text-green-600">{stats.delivered}</div>
                <div className="text-sm text-gray-600">Delivered</div>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="pt-4">
              <div className="text-center">
                <div className="text-2xl font-bold text-red-600">{stats.cancelled}</div>
                <div className="text-sm text-gray-600">Cancelled</div>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="pt-4">
              <div className="text-center">
                <div className="text-lg font-bold text-green-600">₹{stats.totalRevenue.toLocaleString("en-IN")}</div>
                <div className="text-sm text-gray-600">Revenue</div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Filters */}
        <Card className="mb-6">
          <CardContent className="pt-6">
            <div className="flex flex-col md:flex-row gap-4">
              <div className="flex-1">
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
                  <Input
                    placeholder="Search by order number, customer name, or email..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-10"
                  />
                </div>
              </div>
              <div className="flex gap-2">
                <Select value={statusFilter} onValueChange={setStatusFilter}>
                  <SelectTrigger className="w-40">
                    <SelectValue placeholder="Status" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Status</SelectItem>
                    <SelectItem value="pending">Pending</SelectItem>
                    <SelectItem value="processing">Processing</SelectItem>
                    <SelectItem value="shipped">Shipped</SelectItem>
                    <SelectItem value="delivered">Delivered</SelectItem>
                    <SelectItem value="cancelled">Cancelled</SelectItem>
                  </SelectContent>
                </Select>
                <Select value={timeFilter} onValueChange={setTimeFilter}>
                  <SelectTrigger className="w-40">
                    <SelectValue placeholder="Time" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Time</SelectItem>
                    <SelectItem value="today">Today</SelectItem>
                    <SelectItem value="week">This Week</SelectItem>
                    <SelectItem value="month">This Month</SelectItem>
                    <SelectItem value="year">This Year</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Orders List */}
        <div className="space-y-4">
          {filteredOrders.length === 0 ? (
            <Card>
              <CardContent className="pt-6">
                <div className="text-center py-8">
                  <Package className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                  <h3 className="text-lg font-semibold mb-2">No Orders Found</h3>
                  <p className="text-gray-600">No orders match your current filters.</p>
                </div>
              </CardContent>
            </Card>
          ) : (
            filteredOrders.map((order) => (
              <Card key={order.id}>
                <CardHeader>
                  <div className="flex justify-between items-start">
                    <div>
                      <CardTitle className="flex items-center gap-2">
                        Order #{order.orderNumber}
                        <Badge className={getStatusColor(order.status)}>
                          {getStatusIcon(order.status)}
                          <span className="ml-1 capitalize">{order.status}</span>
                        </Badge>
                      </CardTitle>
                      <div className="flex items-center gap-4 text-sm text-gray-600 mt-1">
                        <span className="flex items-center gap-1">
                          <User className="h-4 w-4" />
                          {order.customerName}
                        </span>
                        <span className="flex items-center gap-1">
                          <Calendar className="h-4 w-4" />
                          {new Date(order.date).toLocaleDateString()}
                        </span>
                        <span className="flex items-center gap-1">
                          <DollarSign className="h-4 w-4" />₹{order.totalAmount.toLocaleString("en-IN")}
                        </span>
                      </div>
                    </div>
                    <div className="flex gap-2">
                      <Select
                        value={order.status}
                        onValueChange={(value) => updateOrderStatus(order.id, value as Order["status"])}
                      >
                        <SelectTrigger className="w-32">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="pending">Pending</SelectItem>
                          <SelectItem value="processing">Processing</SelectItem>
                          <SelectItem value="shipped">Shipped</SelectItem>
                          <SelectItem value="delivered">Delivered</SelectItem>
                          <SelectItem value="cancelled">Cancelled</SelectItem>
                        </SelectContent>
                      </Select>
                      <Button variant="outline" size="sm">
                        <Eye className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                    {/* Order Items */}
                    <div>
                      <h4 className="font-medium mb-3">Items ({order.items.length})</h4>
                      <div className="space-y-2">
                        {order.items.map((item) => (
                          <div key={item.id} className="flex items-center gap-3">
                            <img
                              src={item.image || "/placeholder.svg"}
                              alt={item.name}
                              className="w-12 h-12 object-cover rounded"
                            />
                            <div className="flex-1">
                              <p className="text-sm font-medium">{item.name}</p>
                              <p className="text-xs text-gray-600">
                                {item.quantity} × ₹{item.price}
                              </p>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>

                    {/* Customer & Shipping */}
                    <div>
                      <h4 className="font-medium mb-3">Customer & Shipping</h4>
                      <div className="space-y-2 text-sm">
                        <p>
                          <strong>Email:</strong> {order.customerEmail}
                        </p>
                        <p>
                          <strong>Payment:</strong> {order.paymentMethod}
                        </p>
                        <div className="pt-2">
                          <p className="font-medium flex items-center gap-1">
                            <MapPin className="h-4 w-4" />
                            Shipping Address
                          </p>
                          <div className="text-gray-600 ml-5">
                            <p>{order.shippingAddress.name}</p>
                            <p>{order.shippingAddress.street}</p>
                            <p>
                              {order.shippingAddress.city}, {order.shippingAddress.state}
                            </p>
                            <p>{order.shippingAddress.pincode}</p>
                            <p>{order.shippingAddress.phone}</p>
                          </div>
                        </div>
                      </div>
                    </div>

                    {/* Tracking & Actions */}
                    <div>
                      <h4 className="font-medium mb-3">Tracking & Actions</h4>
                      <div className="space-y-3">
                        {order.trackingNumber && (
                          <div>
                            <p className="text-sm font-medium">Tracking Number</p>
                            <p className="text-sm font-mono bg-gray-100 px-2 py-1 rounded">{order.trackingNumber}</p>
                          </div>
                        )}
                        <div className="space-y-2">
                          <Button variant="outline" size="sm" className="w-full bg-transparent">
                            <Edit className="h-4 w-4 mr-2" />
                            Edit Order
                          </Button>
                          <Button variant="outline" size="sm" className="w-full bg-transparent">
                            <Package className="h-4 w-4 mr-2" />
                            Print Label
                          </Button>
                          <Button variant="outline" size="sm" className="w-full bg-transparent">
                            Contact Customer
                          </Button>
                        </div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))
          )}
        </div>
      </div>
    </div>
  )
}
