import { NextResponse } from "next/server"
import { neon } from "@neondatabase/serverless"

// Mock data for fallback
const mockProducts = [
  {
    id: "1",
    name: "Elegant Silk Dress",
    description: "Beautiful silk dress perfect for special occasions",
    price: 2999,
    originalPrice: 3999,
    category: "women",
    stock: 15,
    imageUrl: "/placeholder.svg?height=400&width=300",
  },
  {
    id: "2",
    name: "Cotton Kids T-Shirt",
    description: "Comfortable cotton t-shirt for kids",
    price: 599,
    originalPrice: 799,
    category: "kids",
    stock: 25,
    imageUrl: "/placeholder.svg?height=400&width=300",
  },
]

export async function GET() {
  try {
    if (process.env.DATABASE_URL) {
      const sql = neon(process.env.DATABASE_URL)
      const products = await sql`
        SELECT 
          id,
          name,
          description,
          price,
          original_price as "originalPrice",
          category,
          stock,
          image_url as "imageUrl"
        FROM products 
        ORDER BY created_at DESC
      `
      return NextResponse.json(products)
    } else {
      console.log("No DATABASE_URL, returning mock data")
      return NextResponse.json(mockProducts)
    }
  } catch (error) {
    console.error("Database error:", error)
    return NextResponse.json(mockProducts)
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json()
    const { name, description, price, originalPrice, category, stock, imageUrl } = body

    // Validate required fields
    if (!name || !description || !price || !originalPrice || !category || !stock) {
      return NextResponse.json({ error: "Missing required fields" }, { status: 400 })
    }

    if (process.env.DATABASE_URL) {
      const sql = neon(process.env.DATABASE_URL)

      const [product] = await sql`
        INSERT INTO products (name, description, price, originalPrice, category, stock, image_url)
        VALUES (${name}, ${description}, ${price}, ${originalPrice}, ${category}, ${stock}, ${imageUrl || "/placeholder.svg?height=400&width=300"})
        RETURNING 
          id,
          name,
          description,
          price,
          original_price as "originalPrice",
          category,
          stock,
          image_url as "imageUrl"
      `

      return NextResponse.json(product, { status: 201 })
    } else {
      // Mock response for testing without database
      const newProduct = {
        id: Date.now().toString(),
        name,
        description,
        price,
        originalPrice,
        category,
        stock,
        imageUrl: imageUrl || "/placeholder.svg?height=400&width=300",
      }

      console.log("Mock product created:", newProduct)
      return NextResponse.json(newProduct, { status: 201 })
    }
  } catch (error) {
    console.error("Error creating product:", error)
    return NextResponse.json({ error: "Failed to create product", details: error.message }, { status: 500 })
  }
}
