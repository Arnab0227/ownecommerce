export interface Product {
  id: string
  name: string
  description: string
  price: number
  originalPrice?: number
  category: string
  imageUrl?: string
  stock: number
  rating?: number
  created_at?: string
  updated_at?: string
}

export interface Order {
  id: string
  user_id: string
  total_amount: number
  delivery_address: any
  payment_method: string
  status: "pending" | "confirmed" | "shipped" | "delivered" | "cancelled"
  created_at: string
  updated_at: string
}

export interface OrderItem {
  id: string
  order_id: string
  product_id: string
  quantity: number
  price: number
}
